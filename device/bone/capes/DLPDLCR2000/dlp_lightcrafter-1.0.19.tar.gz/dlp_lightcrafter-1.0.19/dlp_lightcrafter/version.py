# 1.0 
# The following is appended by build.cmd -- do not edit!! 
repo = "https://dlp_cm/val/pico/dpp2607_redist" 
revision = "ff6ca9ee71cd" 
version = "1.0.19" 
