To install on Beagle Bone Black, do:

$ tar -xvf dpp2607-1.0.1.tar.gz
$ cd dpp2607-1.0.1
$ sudo python setup.py install

